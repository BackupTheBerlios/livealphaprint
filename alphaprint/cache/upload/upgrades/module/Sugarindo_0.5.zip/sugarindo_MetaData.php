<?php
$dictionary['quote_tasks'] = array (
	'table' => 'quotes',
 	  'relationships' => array (
		'quote_tasks' => array('lhs_module'=> 'Quotes', 'lhs_table'=> 'quotes', 'lhs_key' => 'id',
							  'rhs_module'=> 'Tasks', 'rhs_table'=> 'tasks', 'rhs_key' => 'parent_id',
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Quotes')
	),
);
$dictionary['quote_notes'] = array (
	'table' => 'quotes',
 	  'relationships' => array (
		'quote_notes' => array('lhs_module'=> 'Quotes', 'lhs_table'=> 'quotes', 'lhs_key' => 'id',
							  'rhs_module'=> 'Notes', 'rhs_table'=> 'notes', 'rhs_key' => 'parent_id',
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Quotes')
	),
);
$dictionary['quote_meetings'] = array (
	'table' => 'quotes',
 	  'relationships' => array (
		'quote_meetings' => array('lhs_module'=> 'Quotes', 'lhs_table'=> 'quotes', 'lhs_key' => 'id',
							  'rhs_module'=> 'Meetings', 'rhs_table'=> 'meetings', 'rhs_key' => 'parent_id',
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Quotes')
	),
);
$dictionary['quote_calls'] = array (
	'table' => 'quotes',
 	  'relationships' => array (
		'quote_calls' => array('lhs_module'=> 'Quotes', 'lhs_table'=> 'quotes', 'lhs_key' => 'id',
							  'rhs_module'=> 'Calls', 'rhs_table'=> 'calls', 'rhs_key' => 'parent_id',
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Quotes')
	),
);
$dictionary['quotes_documents'] =
array (
	'table' => 'quotes_documents',
	'fields' => array (
		array('name' => 'id', 'type' =>'char', 'len'=>'36', 'default'=>''),
		array('name' => 'quote_id', 'type' =>'char', 'len'=>'36'),
		array('name' => 'document_id', 'type' =>'char', 'len'=>'36'),
		array('name' => 'date_modified','type' => 'datetime'),
		array('name' => 'deleted', 'type' =>'bool', 'len'=>'1', 'default'=>'0', 'required'=>true)
	),

	'indices' => array (
		array('name' =>'quotes_documentspk', 'type' =>'primary', 'fields'=>array('id')),
		array('name' =>'idx_quote_doc_quote', 'type' =>'index', 'fields'=>array('quote_id')),
		array('name' =>'idx_quote_doc_doc', 'type' =>'index', 'fields'=>array('document_id')),
		array('name' => 'idx_quote_doc', 'type'=>'alternate_key', 'fields'=>array('quote_id','document_id'))
	),

	'relationships' => array (
		'quotes_documents' => array(
			'lhs_module'	=> 'Quotes',
			'lhs_table'		=> 'quotes',
			'lhs_key'		=> 'id',
			'rhs_module'	=> 'Documents',
			'rhs_table'		=> 'documents',
			'rhs_key'		=> 'id',
			'relationship_type'=>'many-to-many',
			'join_table'	=> 'quotes_documents',
			'join_key_lhs'	=> 'quote_id',
			'join_key_rhs'	=>'document_id',
		)
	)
);

$dictionary['product_notes'] = array (
	'table' => 'products',
 	  'relationships' => array (
		'product_notes' => array('lhs_module'=> 'Products', 'lhs_table'=> 'products', 'lhs_key' => 'id',
							  'rhs_module'=> 'Notes', 'rhs_table'=> 'notes', 'rhs_key' => 'parent_id',
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Products'),			
	),
);

$dictionary['product_tasks'] = array (
	'table' => 'products',
 	  'relationships' => array (
		'product_tasks' => array('lhs_module'=> 'Products', 'lhs_table'=> 'products', 'lhs_key' => 'id',
							  'rhs_module'=> 'Tasks', 'rhs_table'=> 'tasks', 'rhs_key' => 'parent_id',
							  'relationship_type'=>'one-to-many', 'relationship_role_column'=>'parent_type',
							  'relationship_role_column_value'=>'Products')		
	),
);


$dictionary['products_pricebooks'] = array (
	'table' => 'products_pricebooks',
	'fields' => array (
    'id' => array(
		'name' =>'id', 
		'type' =>'char', 
		'len'=>'36', 
		'default'=>''
	), 
    'product_id' =>array(
		'name' =>'product_id', 
		'type' =>'char', 
		'len'=>'36', 
		), 
	'pricebook_id' =>array(
		'name' =>'pricebook_id', 
		'type' =>'char', 
		'len'=>'36',
	),
	'trade_price' => array(
		'name' =>'trade_price', 
		'type' =>'double'
	),
	'created_by' =>array(
		'name' =>'created_by', 
		'type' =>'char', 
		'len'=>'36',
	),
	'date_modified'=>array (
		'name' => 'date_modified',
		'type' => 'datetime'
	), 
	'deleted'=>array(
		'name' =>'deleted', 
		'type' =>'bool', 
		'len'=>'1', 
		'default'=>'0', 
		'required'=>true
	), 
	
    
	  ),
 	'indices' => array (
	       array('name' =>'products_pricebookspk', 'type' =>'primary', 'fields'=>array('id'))
	      , array('name' =>'idx_pro_prc_pro', 'type' =>'index', 'fields'=>array('product_id'))
	      , array('name' =>'idx_prc_pro_prc', 'type' =>'index', 'fields'=>array('pricebook_id'))	      
	      ,array('name'=>'idx_products_pricebooks','type'=>'alternate_key',
		  'fields'=>array('product_id','pricebook_id'))      
 		  ) ,
		  
  'relationships' => array (
			'products_pricebooks' => array('lhs_module'=> 'Products', 'lhs_table'=> 'products', 'lhs_key' => 'id',
							  'rhs_module'=> 'Pricebooks', 'rhs_table'=> 'pricebooks', 'rhs_key' => 'id',
							  'relationship_type'=>'many-to-many',
							  'join_table'=> 'products_pricebooks', 'join_key_lhs'=>'product_id', 'join_key_rhs'=>'pricebook_id',)
	),
);






?>
