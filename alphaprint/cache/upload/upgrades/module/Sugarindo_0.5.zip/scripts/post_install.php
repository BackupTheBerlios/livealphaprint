<?php

// Author: Goodwill Consulting http://www.goodwill.co.id
function post_install( ) {
	
echo '<p>Sugarindo is free for Sugar Open Source users. Commercial support is available, please visit <A HREF="http://www.goodwill.co.id">www.goodwill.co.id</A></p><br/>';

}

?>
