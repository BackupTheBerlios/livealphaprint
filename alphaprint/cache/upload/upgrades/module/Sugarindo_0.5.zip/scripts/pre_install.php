<?php

// Author: Goodwill Consulting http://www.goodwill.co.id

function pre_install( ) {
	
echo '<h3>.: DISCLAIMER :.<h3>'; 
echo '<p>THIS MODULE IS PROVIDED UNDER THIS LICENSE ON AN "AS IS" BASIS, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED. USE WITH YOU OWN RISK</p><br/>';

}

?>
