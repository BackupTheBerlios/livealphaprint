<?

$app_strings['ERR_INVALIDNUMBER'] = 'invalid number';
$app_strings['ERR_DUPLICATED'] = 'duplicate record';
$app_strings['ERR_ONE_PRODUCT_REQUIRED'] = 'one product required';
$app_list_strings['moduleList']['Paper']='Paper';


############# Begin Paper Module Dropdowns ####################

$app_list_strings['paper_status_dom'] = array (
    '' => '',
  'status1' => 'status1',
  'status2' => 'status2',
  'status3' => 'status3',
  'status4' => 'status4',
);
 
$app_list_strings['paper_size_unit_dom'] = array (
    '' => '',
  'mm' => 'Milimeters',
  'cm' => 'Cantimeters',
  'dm' => 'Decimeter',
  'meter' => 'Meters',
);

$app_list_strings['paper_weight_unit_dom'] = array (
    '' => '',
  'gram' => 'Grams',
  'kilo' => 'Kilograms',
  'ton' => 'Tons',
);

$app_list_strings['paper_chrome_dom'] = array (
    '' => '',
  'chromed' => 'Choremed',
  'not_chromed' => 'Not Choremed',
);

$app_list_strings['paper_texture_dom'] = array (
    '' => '',
  'texture1' => 'texture1',
  'texture2' => 'texture2',
  'texture3' => 'texture3',
);

$app_list_strings['paper_absorption_dom'] = array (
    '' => '',
  'absorption1' => 'absorption1',
  'absorption2' => 'absorption2',
);

$app_list_strings['paper_color_dom'] = array (
    '' => '',
  'color1' => 'color1',
  'color2' => 'color2',
);

$app_list_strings['paper_manufacture_dom'] = array (
    '' => '',    
  'manufacture1' => 'manufacture1',
  'manufacture2' => 'manufacture2',
);

$app_list_strings['paper_quality_dom'] = array (
    '' => '',
  'quality1' => 'quality1',
  'quality2' => 'quality2',
);

$app_list_strings['paper_price_on_dom'] = array (
    '' => '',
  'price_for1' => 'Price for1',
  'price_for2' => 'Price for2',
);

$app_list_strings['paper_price_unit_dom'] = array (
    '' => '',
  'Dollars' => 'Dollars',
  'Euro' => 'Euro',
  'Leva' => 'Leva',
);

$app_list_strings['paper_side_dom'] = array (
    '' => '',
  'One-Sided' => 'One-Sided',
  'Two-Sided' => 'Two-Sided',
);
############# End Paper Module Dropdowns #################### 
?>
